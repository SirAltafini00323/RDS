@extends("layouts/layoutAdmin")

@section('content')
<article class="card  mb-3">
<div class="card-header">
          <h2 class="card-title">Stock disponible</h2>
        </div>
        <div class="card-body">
        <section >
                <table class="table">
                    <thead>
                      <tr>
                        <th>Modèle </th>
                        <th>Nom</th>
                        <th>Prix</th>
                        <th>Quantité disponible</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    @foreach($items as $item)
                      <tr>
                        <td>{{$item->categorie->nom}}</td>
                        <td>{{$item->nom}}</td>
                        <td>{{$item->prix}}</td>
                        <td><div class="input-group" style="display:inline-block">
                        <form method="POST" action="{{ route('pieces.stock.store') }}" >
                            @csrf
                            <input type="hidden" value="{{$item->id}}" name="piece_id">
                            <div class="row">
                              <div class="col-md-6">
                              <input type="text" class="form-control" name="stock" value="{{$item->stock}}">
                              </div>
                              <div class="col-md-6">
                              <span class="input-group-append"> 
                              <button type="submit" class="btn btn-primary">Actualiser</button>
                            </span>
                              </div>
                            </div>
                           
                           
                        </form>
                        </div></td>
                        <td> <a href="{{route('pieces.edit',$item->id)}}" class="btn btn-outline-primary"> Modifier </a></td>

                      </tr>    
                    @endforeach  
                      
                      
                    </tbody>
                  </table>
            </div> <!-- card-body .// -->
        </article>
@endsection